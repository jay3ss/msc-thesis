%  sir6.m
% Matlab file for Part 6 of the Preditor-Prey Models module
global b k

disp('********************************************')
disp('Part 6:  Herd Immunity ')
disp('********************************************')
disp('  ')

    format short
    
    disp('--------------------------------------------')
    disp('Answer questions in steps 1-6 of Part 6.')
    disp('Use MATLAB comments in your diary file.')
    disp('Include any MATLAB calculations you see fit.')
    disp(' ')
    disp(' ')
    disp('------------------------------------------------') 
    disp('To go on to part 7 of this module,')
    disp('type: sir7')
    disp(' ')