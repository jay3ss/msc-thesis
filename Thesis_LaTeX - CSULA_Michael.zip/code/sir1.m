%  sir1.m
% Matlab file for Part 1 of the SIR Model for Spread
% of Disease module.

disp('*********************************************')
disp('Part 1:  Background: Hong Kong Flu')
disp('*********************************************')
disp('  ')    

    format short

    disp('There are no questions to be answered in')
    disp('Part 1.')
    disp(' ')
    disp(' ')
    disp('Go on to Part 2 by typing:  sir2.  ')
    disp(' ')
    


