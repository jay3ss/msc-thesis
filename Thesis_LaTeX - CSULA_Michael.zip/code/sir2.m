%  sir2.m
% Matlab file for Part 2 of the SIR Model for Spread
% of Disease module.

disp('*********************************************')
disp('Part 2:  The Differential Equation Model')
disp('*********************************************')
disp('  ')    

    format short

    disp('Answer the questions in steps 1-7 of Part 2')
    disp('as MATLAB comments in your diary file.')
    disp(' ')
    disp(' ')
    disp('--------------------------------------------')
    disp('After you have finished, to go on to Part 3,')
    disp('type:  sir3.')
    disp(' ')
    


