%  sir7.m
% Matlab file for Part 7 of the Preditor-Prey Models module

disp('********************************************')
disp('Part 7:  Summary ')
disp('********************************************')
disp('  ')

    format short
    
    disp('Answer questions in steps 1-8 of the Summary.')
    disp('Use MATLAB comments in your diary file.')
    disp(' ')