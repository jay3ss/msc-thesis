%  sir5.m
% Matlab file for Part 5 of the Preditor-Prey Models module
global b k

disp('********************************************')
disp('Part 5:  The Contact Number ')
disp('********************************************')
disp('  ')

    format short
    
    disp('--------------------------------------------')
    disp('Answer questions in steps 1-5 of Part 5.')
    disp('Use MATLAB comments in your diary file.')
    disp('Include any MATLAB calculations you see fit.')
    disp(' ')
    disp(' ')
    disp('------------------------------------------------') 
    disp('To go on to part 6 of this module,')
    disp('type: sir6')
    disp(' ')